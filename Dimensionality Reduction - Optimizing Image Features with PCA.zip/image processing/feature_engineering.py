import numpy as np
import os
import glob
import time
import cv2
from matplotlib import pyplot as plt
from sklearn.decomposition import PCA


def resize_frame(frame, target_width):
    """
    Resizes the given frame to the specified width while maintaining the aspect ratio.
    """
    height, width = frame.shape[:2]
    if target_width > 0:  # Use target_width = 0 for no resizing
        ratio = float(width) / target_width
        new_height = int(round(float(height) / ratio))
        return cv2.resize(frame, (target_width, new_height))
    return frame


def split_into_blocks(image):
    """
    Splits an image into two horizontal blocks.
    """
    mid_col = image.shape[1] // 2
    return [image[:, :mid_col], image[:, mid_col:]]


def extract_features(image, plot=False):
    """
    Extracts features from the image, including LBP, color, and HOG.
    """
    start_time = time.perf_counter()

    blocks = split_into_blocks(image)

    # Example: Extract features from each block using the respective feature functions
    features_lines = []
    features_lbp = []
    features_color = []
    features_hog = []

    for block in blocks:
        try:
            lines, _ = featuresLines.getLineFeatures(block)
            lbp, _ = featuresLBP2.getLBP(block)
            color, _ = featuresColor.getRGBS(block, plot)
            hog, _ = featuresHOG.getHOG(block)

            features_lines.extend(lines)
            features_lbp.extend(lbp)
            features_color.extend(color)
            features_hog.extend(hog)
        except Exception as e:
            print(f"Error extracting features: {e}")

    total_time = time.perf_counter() - start_time
    print(f"Feature extraction completed in {total_time:.2f} seconds")

    feature_vector = features_lines + features_lbp + features_color + features_hog
    feature_names = ["Lines", "LBP", "Color", "HOG"]

    return feature_vector, feature_names


def process_image(file_name, plot=False):
    """
    Processes a single image file and extracts features.
    """
    try:
        image = cv2.imread(file_name, cv2.IMREAD_COLOR)
        if image is None:
            raise ValueError("Image could not be loaded.")
        return extract_features(image, plot)
    except Exception as e:
        print(f"Error processing image {file_name}: {e}")
        return None, None


def process_images_from_directory(directory):
    """
    Processes all images in a directory and extracts their features.
    """
    image_extensions = ('*.jpg', '*.png')
    image_files = []
    for ext in image_extensions:
        image_files.extend(glob.glob(os.path.join(directory, ext)))

    image_files.sort()

    features = []
    for i, file in enumerate(image_files):
        print(f"Processing image {i + 1}/{len(image_files)}: {file}")
        feature_vector, _ = process_image(file)
        if feature_vector is not None:
            features.append(feature_vector)

    return np.array(features), image_files


def perform_pca(features, n_components=2):
    """
    Reduces dimensionality using PCA.
    """
    pca = PCA(n_components=n_components)
    transformed_features = pca.fit_transform(features)
    print(f"PCA completed. Shape of transformed features: {transformed_features.shape}")
    return transformed_features, pca.components_


def visualize_features(features, files, feature_names):
    """
    Visualizes features after dimensionality reduction with PCA.
    """
    reduced_features, _ = perform_pca(features, 2)

    plt.figure(figsize=(8, 8))
    for idx, (x, y) in enumerate(reduced_features):
        image = cv2.imread(files[idx], cv2.IMREAD_COLOR)
        if image is not None:
            plt.scatter(x, y)
            plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB),
                       extent=(x - 0.1, x + 0.1, y - 0.1, y + 0.1), alpha=0.5)
    plt.title("Feature Visualization")
    plt.show()
