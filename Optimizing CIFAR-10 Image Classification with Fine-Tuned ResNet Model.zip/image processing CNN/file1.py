# Importing required packages
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
import numpy as np
import torchvision
from torchvision import datasets, models, transforms
from torchvision.utils import make_grid
from torch.utils.data import random_split, DataLoader
import matplotlib.pyplot as plt
import time
import os
import copy

# Device configuration
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# Normalization parameters for CIFAR-10
normalization_params = ((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))

# Data augmentation and transformation
train_transforms = transforms.Compose([
    transforms.RandomCrop(32, padding=4, padding_mode='reflect'),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize(*normalization_params, inplace=True)
])

test_transforms = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(*normalization_params, inplace=True)
])

# Downloading CIFAR-10 dataset and applying transformations
train_dataset = datasets.CIFAR10(root="data/", train=True, download=True, transform=train_transforms)
test_dataset = datasets.CIFAR10(root="data/", train=False, download=True, transform=test_transforms)

# Splitting train dataset into training and validation sets
split_ratio = 0.2
train_size = int((1 - split_ratio) * len(train_dataset))
val_size = len(train_dataset) - train_size
train_data, val_data = random_split(train_dataset, [train_size, val_size])

# Creating DataLoaders
batch_size = 32
train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True, pin_memory=True)
val_loader = DataLoader(val_data, batch_size=batch_size, shuffle=False, pin_memory=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, pin_memory=True)

dataloaders = {'train': train_loader, 'validation': val_loader}
dataset_sizes = {'train': train_size, 'validation': val_size}
class_names = train_dataset.classes

# Function to display a grid of images
def plot_images(dataloader):
    for images, labels in dataloader:
        fig, ax = plt.subplots(figsize=(10, 10))
        ax.imshow(make_grid(images, nrow=8).permute(1, 2, 0))
        ax.axis('off')
        plt.show()
        break

# Function to display a single image
def imshow(image, title=None):
    image = image.numpy().transpose((1, 2, 0))
    mean = np.array([0.5, 0.5, 0.5])
    std = np.array([0.5, 0.5, 0.5])
    image = std * image + mean
    image = np.clip(image, 0, 1)
    plt.imshow(image)
    if title:
        plt.title(title)
    plt.pause(0.001)

# Training function
def train_model(model, criterion, optimizer, scheduler, num_epochs=25):
    since = time.time()
    best_model_wts = copy.deepcopy(model.state_dict())
    best_acc = 0.0

    for epoch in range(num_epochs):
        print(f"Epoch {epoch}/{num_epochs - 1}")
        print("-" * 10)

        for phase in ['train', 'validation']:
            if phase == 'train':
                model.train()
            else:
                model.eval()

            running_loss = 0.0
            running_corrects = 0

            for inputs, labels in dataloaders[phase]:
                inputs, labels = inputs.to(device), labels.to(device)
                optimizer.zero_grad()

                with torch.set_grad_enabled(phase == 'train'):
                    outputs = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss = criterion(outputs, labels)

                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels.data)

            if phase == 'train':
                scheduler.step()

            epoch_loss = running_loss / dataset_sizes[phase]
            epoch_acc = running_corrects.double() / dataset_sizes[phase]

            print(f"{phase} Loss: {epoch_loss:.4f} Acc: {epoch_acc:.4f}")

            if phase == 'validation' and epoch_acc > best_acc:
                best_acc = epoch_acc
                best_model_wts = copy.deepcopy(model.state_dict())

        print()

    time_elapsed = time.time() - since
    print(f"Training complete in {time_elapsed // 60:.0f}m {time_elapsed % 60:.0f}s")
    print(f"Best Validation Accuracy: {best_acc:.4f}")
    model.load_state_dict(best_model_wts)
    return model

# Visualization function for predictions
def visualize_model_predictions(model, num_images=4):
    model.eval()
    images_shown = 0
    fig = plt.figure()

    with torch.no_grad():
        for inputs, labels in dataloaders['validation']:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _, preds = torch.max(outputs, 1)

            for i in range(inputs.size(0)):
                images_shown += 1
                ax = plt.subplot(num_images // 2, 2, images_shown)
                ax.axis('off')
                ax.set_title(f"Predicted: {class_names[preds[i]]}")
                imshow(inputs.cpu().data[i])

                if images_shown == num_images:
                    return

# Initializing a pre-trained model and fine-tuning
def initialize_model(freeze=True):
    model = models.resnet18(pretrained=True)
    if freeze:
        for param in model.parameters():
            param.requires_grad = False
    num_ftrs = model.fc.in_features
    model.fc = nn.Linear(num_ftrs, len(class_names))
    return model

# Training a model
def train_and_evaluate(model, num_epochs=25, learning_rate=0.001):
    model = model.to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.SGD(filter(lambda p: p.requires_grad, model.parameters()), lr=learning_rate, momentum=0.9)
    scheduler = lr_scheduler.StepLR(optimizer, step_size=7, gamma=0.1)

    return train_model(model, criterion, optimizer, scheduler, num_epochs)

# Plot sample images
plot_images(train_loader)

# Train and evaluate the pre-trained model
model_ft = initialize_model(freeze=False)
model_ft = train_and_evaluate(model_ft)
visualize_model_predictions(model_ft)

# Train a fine-tuned model
model_tuned = initialize_model(freeze=True)
model_tuned = train_and_evaluate(model_tuned)
visualize_model_predictions(model_tuned)
