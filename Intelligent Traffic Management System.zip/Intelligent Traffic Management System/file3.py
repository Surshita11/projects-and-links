import cv2
import numpy as np
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

def capture_and_process_image(image_path, min_range=60, max_range=175, save_path="sliced_with_bg.tif"):
    """
    Captures and processes an image by slicing pixel intensities within a range.
    
    :param image_path: Path to the input image.
    :param min_range: Minimum intensity value for slicing.
    :param max_range: Maximum intensity value for slicing.
    :param save_path: Path to save the processed image.
    :return: Count of white pixels in the processed image.
    """
    # Check if the file exists
    if not os.path.exists(image_path):
        logging.error(f"Image not found at {image_path}")
        return None
    
    # Read the image
    img = cv2.imread(image_path, 0)
    if img is None:
        logging.error(f"Failed to load image from {image_path}")
        return None

    logging.info("Processing the image...")

    # Find width and height of the image
    row, column = img.shape

    # Create an array for the sliced image
    img_sliced = np.zeros((row, column), dtype='uint8')

    # Process the image
    for i in range(row):
        for j in range(column):
            if min_range < img[i, j] < max_range:
                img_sliced[i, j] = 255
            else:
                img_sliced[i, j] = 0

    # Display the images
    cv2.imshow('Original Image', img)
    cv2.imshow('Processed Image', img_sliced)

    # Save the processed image
    cv2.imwrite(save_path, img_sliced)
    logging.info(f"Processed image saved at {save_path}")

    # Calculate the white pixel count
    white_pixel_count = np.sum(img_sliced == 255)
    logging.info(f"Count of white pixels: {white_pixel_count}")

    # Show histogram of the original image
    cv2.imshow('Histogram', cv2.calcHist([img], [0], None, [256], [0, 256]))
    
    # Cleanup and close windows
    cv2.waitKey(1000)
    cv2.destroyAllWindows()
    
    return white_pixel_count

def main():
    # Define paths
    image_path = '/home/ysapi/Desktop/ProjectPython/Frame_1.jpg'
    processed_image_path = 'sliced_with_bg.tif'

    # Define intensity thresholds
    min_intensity = 60
    max_intensity = 175

    # Capture and process the image
    white_pixel_count = capture_and_process_image(image_path, min_intensity, max_intensity, processed_image_path)
    
    if white_pixel_count is not None:
        logging.info(f"Junction (live) 1 white pixel count: {white_pixel_count}")
    else:
        logging.error("Processing failed.")

if __name__ == "__main__":
    main()
