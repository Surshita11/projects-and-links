import RPi.GPIO as GPIO
import time
from Mainduplicate import overall
from RGBTOGRAY import capturing

# GPIO pin configuration
GPIO.setmode(GPIO.BCM)
TRAFFIC_LIGHTS = {
    'J1': {'R': 2, 'Y': 26, 'G': 3},
    'J2': {'R': 17, 'Y': 22, 'G': 27},
    'J3': {'R': 10, 'Y': 11, 'G': 9},
    'J4': {'R': 5, 'Y': 13, 'G': 6}
}

# Initialize GPIO pins
for light in TRAFFIC_LIGHTS.values():
    for pin in light.values():
        GPIO.setup(pin, GPIO.OUT)

# Default signal timings (seconds)
RED_TIME = 40
GREEN_TIME = 30
YELLOW_TIME = 5
TRAFFIC_ADJUSTMENT = 15  # Additional time adjustment based on traffic

# Function to set all lights of a junction
def set_lights(junction, red=False, yellow=False, green=False):
    GPIO.output(TRAFFIC_LIGHTS[junction]['R'], red)
    GPIO.output(TRAFFIC_LIGHTS[junction]['Y'], yellow)
    GPIO.output(TRAFFIC_LIGHTS[junction]['G'], green)

# Function to turn all lights off
def reset_all_lights():
    for junction in TRAFFIC_LIGHTS:
        set_lights(junction)

# Dynamic traffic adjustment
def time_change():
    traffic_volumes = {
        'J1': overall(),
        'J2': 25000,  # Placeholder: Replace with actual J2 volume logic
        'J3': 21000,  # Placeholder: Replace with actual J3 volume logic
        'J4': 30000   # Placeholder: Replace with actual J4 volume logic
    }
    min_junction = min(traffic_volumes, key=traffic_volumes.get)

    # Turn on green light for the junction with the least traffic
    for junction in TRAFFIC_LIGHTS:
        if junction == min_junction:
            set_lights(junction, green=True)
        else:
            set_lights(junction, red=True)

    # Green light duration
    time.sleep(GREEN_TIME + TRAFFIC_ADJUSTMENT)

    # Yellow light for all
    reset_all_lights()
    for junction in TRAFFIC_LIGHTS:
        set_lights(junction, yellow=True)
    time.sleep(YELLOW_TIME)

# Main function
def main():
    try:
        print("Traffic signal controller running. Press Ctrl+C to stop.")
        while True:
            capturing()  # Traffic capturing logic
            time.sleep(25)  # Delay between captures
            time_change()
    except KeyboardInterrupt:
        print("\nProgram interrupted by user. Cleaning up...")
    finally:
        reset_all_lights()
        GPIO.cleanup()
        print("GPIO cleaned up. Program exited safely.")

# Run the main function
if __name__ == "__main__":
    main()
