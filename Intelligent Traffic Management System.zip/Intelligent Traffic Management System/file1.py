# Import required libraries
import cv2
import os
from datetime import datetime

# Function to create the save directory if it doesn't exist
def ensure_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)
        print(f"Directory '{path}' created successfully.")
    else:
        print(f"Saving frames to existing directory: '{path}'")

# Define default settings
save_path = r'/home/ysapi/Desktop/ProjectPython'
frame_interval = 5000  # Interval in milliseconds to save frames
resolution = (1280, 720)  # Desired resolution (Width, Height)

# Ensure the save directory exists
ensure_directory(save_path)
os.chdir(save_path)

# Initialize variables
image_index = 1
elapsed_time = 0

# Open the camera
camera = cv2.VideoCapture(0)
if not camera.isOpened():
    print("Error: Could not access the camera.")
    exit()

# Set resolution
camera.set(cv2.CAP_PROP_FRAME_WIDTH, resolution[0])
camera.set(cv2.CAP_PROP_FRAME_HEIGHT, resolution[1])

print("Press 'q' to quit the application.")
while True:
    # Capture a frame from the camera
    ret, frame = camera.read()
    if not ret:
        print("Error: Failed to capture the frame.")
        break

    # Overlay the current date and time on the frame
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    font = cv2.FONT_HERSHEY_PLAIN
    cv2.putText(frame, timestamp, (20, 40), font, 2, (255, 255, 255), 2, cv2.LINE_AA)

    # Display the live video feed
    cv2.imshow('Live Video', frame)

    # Wait for user input or a timeout (in milliseconds)
    key = cv2.waitKey(100)

    # Increment the elapsed time counter
    elapsed_time += 100

    # Exit the loop if the user presses 'q'
    if key == ord('q'):
        break

    # Save the frame every defined interval
    if elapsed_time >= frame_interval:
        # Generate a unique filename for the frame
        filename = f'Frame_{image_index}.jpg'

        # Save the captured frame to the specified path
        cv2.imwrite(filename, frame)
        print(f"Saved: {filename} at {timestamp}")

        # Update variables for the next frame
        image_index += 1
        elapsed_time = 0

# Release the camera resource
camera.release()

# Close all OpenCV windows
cv2.destroyAllWindows()
print("Application closed successfully.")
